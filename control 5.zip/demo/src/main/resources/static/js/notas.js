function NotasController(option){
	$("#msg").hide();
	$("#msg").removeClass("alert-success").addClass("alert-danger");
	var token = $("meta[name='_csrf']").attr("content");
	
	switch(option){
	case "list":
		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/notas/list",
			success : function(res) {
				$('#notastable').bootstrapTable('load', res);
				$('#notastable tbody').on('click', 'tr', function () {
					$("#idnotas").val($(this).find("td:eq(0)").text());
					$("#idalumno").val($(this).find("td:eq(1)").text());
					$("#idasignatura").val($(this).find("td:eq(2)").text());
					$("#nota1").val($(this).find("td:eq(3)").text());
					$("#nota2").val($(this).find("td:eq(4)").text());
					$("#nota3").val($(this).find("td:eq(5)").text());
					$("#promedio").val($(this).find("td:eq(6)").text());
					});
				$("#mymodal").modal({show:true});
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("Error en busqueda de notas.")
			}
		});       			
		break;
	case "get":
		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/notas/get",
			data : "idnotas="+$("#idnotas").val(),
			success : function(res) {
				if (res == null || res == "") {
					$("#msg").show();
					$("#msg").html("No se encontraron registros.");
				} else {	
					$("#idnotas").val(res.idnotas);
					$("#idalumno").val(res.idalumno);
					$("#idasignatura").val(res.idasignatura);
					$("#nota1").val(res.nota1);
					$("#nota2").val(res.nota2);
					$("#nota3").val(res.nota3);
					$("#promedio").val(res.promedio);
					}
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("Error en busqueda.");
			}
		});       			
		break;
	case "insert":
		$("#idnotas").val(0),
		$("#idalumno").val(0),
		$("#idasignatura").val(0),
		$("#nota1").val(0),
		$("#nota2").val(0),
		$("#nota3").val(0),
		$("#promedio").val(0)
		break;
	case "update":
		var json = 
			{
				'idnotas': $("#idnotas").val(),
				'idalumno': $("#idalumno").val(),
				'idasignatura': $("#idasignatura").val(),
				'nota1': $("#nota1").val(),
				'nota2': $("#nota2").val(),
				'nota3': $("#nota3").val(),
				'promedio': $("#promedio").val(),
			};

		var postData = JSON.stringify(json);

		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/notas/update",
			data : postData,
			contentType : "application/json; charset=utf-8",
			dataType : "json",
			success : function(res) {
				if (res == 1) {
					$("#msg").removeClass("alert-danger").addClass("alert-success");
					$("#msg").show();
					$("#msg").html("Registro modificado correctamente.");
				} else {
					$("#msg").show();
					$("#msg").html("No se pudo modificar el registro.");
				}
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("No se pudo modificar el registro.");
			}
		});       	
    break;
	case "delete":
		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/notas/delete",
			data : "idnotas="+$("#isnotas").val(),
			success : function(res) {
				if (res == 1) {
					$("#msg").removeClass("alert-danger").addClass("alert-success");
					$("#msg").show();
					$("#msg").html("Registro eliminado correctamente.");
				} else {
					$("#msg").show();
					$("#msg").html("No se pudo eliminar el registro.");
				}
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("No se pudo eliminar el registro.");
			}
		});
		break;
	default:
		$("#msg").show();
		$("#msg").html("Opción incorrecta.");
	}
}
