var a=null;
var b=null;
var f=null;

function mostrar(){   //con un ciclo for y un append pobla el boton dropdown para mostrar los cursos que corresponden al profesor y 
	                  //usar el metodo onclick para llamar a la funcion registrarid cuando se clickee
	$.ajax({
		type:"post",
		url:"/paginaprofesor/listacurso",
		data :$("#rutprofesor").val(),
		success:function(res){
			for(var x=0;x<res.length;x++){
				$('#desplegar').append("<li><a onclick='registrarid("+x+")';>"+res[x].curnivel+" "+res[x].curletra+"</a></li>");
				
			}
			a=res;
			},
			error:function(){
				alert("error");
			}
	});
}

function registrarid(x){  //asigna el idcurso, curletra, curnivel y el id_asignatura seleccionado ademas de dar un titulo a la tabla 
	                      //y llamar la funcion mostraralumnos
	$("#idcurso").val(a[x].idcurso);
	$("#curletra").val(a[x].curletra);
	$("#curnivel").val(a[x].curnivel);
	$("#id_asignatura").val(a[x].id_asignatura);
	$.ajax({
		type:"post",
		url:"/paginaprofesor/obtenerasignatura",
		data:"id_asignatura="+$("#id_asignatura").val(),
		success:function(res){
			$("#asignombre").val(res.asignombre);
			$("#titulotabla").text("Curso "+$("#curnivel").val()+":"+$("#curletra").val()+" - Asignatura: "+$("#asignombre").val());
		}
	})
	mostraralumnos();
}

function mostraralumnos(){ //primero borra el texto de la tabla en blanco y borra el cuerpo de la tabla para poder actualizar la tabla y que 
	                       //no se agregue hacia abajo con el append en caso de elegir otro alumno despues del primero,  
	$.ajax({
		type : "post",
	   // headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
		url : "/paginaprofesor/listaalumnocurso",
		data : "idcurso="+$("#idcurso").val(),
		success : function(res){
			$("#tablaenblanco").remove();
			$("#alumnostable tbody").remove();
			for(var x=0; x<res.length;x++){
				$("#alumnostable").append("<tbody class='table table-hover'><tr style='background:#fff' onclick='tablanotas("+x+")'><td>"+res[x].nombrealumno+"</td>" +
						"<td>"+res[x].alumnapellidopat+"</td>" +
								"<td>"+res[x].alumnapellidomat+"</td></tr></tbody>").text();
			}
			b=res;
			}
	});
}
function tablanotas(x){
	$("#rutalumno").val(b[x].rutalumno);
	$.ajax({
		type:"post",
		url:"/paginaprofesor/obtenernotas",
		data:"rutalumno="+$("#rutalumno").val(),
		success:function(res){
				$("#tablanotasdata tbody").remove();
				$("#tablanotasdata").append("<tbody><tr><td><input id='nota1' type='text' class='form-control' name='nota1' required></td>" +
						"<td><input id='nota2' type='text' class='form-control' name='nota2' required></td>" +
						"<td><input id='nota3' type='text' class='form-control' name='nota3' required></td>" +
						"<td><input id='promedio' type='text' class='form-control' name='promedio' required></td></tr></tbody>");
				for(var aux=0;aux<res.length-1;aux++){
					if($("#id_asignatura").val()==res[aux].idasignatura){
						break;
					}
				}
				console.log(res[aux]);
						$("#nota1").val(res[aux].nota1);
						$("#nota2").val(res[aux].nota2);
						$("#nota3").val(res[aux].nota3);
						$("#promedio").val(res[aux].promedio);	
						$("#id_asignatura").val(res[aux].idasignatura);
		}
	});$("#tablanotas .close").click();
			/*});*/
			$("#tablanotas").modal({show:true});
			
}
function updatenotas(){
	var json={
			'nota1': $("#nota1").val(),
			'nota2': $("#nota2").val(),
			'nota3': $("#nota3").val(),
			'promedio': $("#promedio").val(),
			'idasignatura':$("#id_asignatura").val(),
			'rutalumno':$("#rutalumno").val()
	};
	var postData = JSON.stringify(json);
	$.ajax({
		type : "post",
			url : "/paginanotas/updatenotas",
			data : postData,
			contentType : "application/json; charset=utf-8",
			dataType : "json",
			success: function (res){
				if (res == 1) {
					alert("Notas ingresadas correctamente.");
				} else {
					console.log($("#rutalumno").val());
					console.log($("#id_asignatura").val());
					console.log(json);
					alert("No se pudo ingresar notas.");
				}
			},
			error : function() {
				alert("No se pudo modificar las notas.");
			}
	});
}