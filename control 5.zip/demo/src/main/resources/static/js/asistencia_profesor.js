var auxListaCursos=null; //auxiliar que guarda una lista de objetos ProfesorDTO con {curnivel,curletra, idcurso, id_asignatura, rutprofesor}

function botonCursos(){
	$.ajax({
		type:"post",
		url:"/paginaprofesor/listacurso",
		data :$("#rutprofesor").val(),
		success:function(res){
			for(var x=0;x<res.length;x++){
				$('#desplegar').append("<li><a onclick='mostrarTablaAsistencia("+x+")';>"+res[x].curnivel+" "+res[x].curletra+"</a></li>");
				
			}
			auxListaCursos=res;
			},
			error:function(){
				alert("error");
			}
	});
}

function mostrarTablaAsistencia(x){
	//guardo los valores de cursos e idasistencia requerido para la query de obtener el nombre del cursos
	$("#curnivel").val(auxListaCursos[x].curnivel);
	$("#curletra").val(auxListaCursos[x].curletra);
	$("#idasignatura").val(auxListaCursos[x].idasignatura);
	$("#idcurso").val(auxListaCursos[x].idcurso);
	$.ajax({
		type:"post",
		url:"/paginaprofesor/obtenerasignatura",
		data:"id_asignatura="+$("#id_asignatura").val(),
		success:function(res){
			$("#asignombre").val(res.asignombre);
			$("#titulotablaasistencia").text("Asistencia "+$("#curnivel").val()+":"+$("#curletra").val()+" - Asignatura: "+$("#asignombre").val());
		}
	})
	poblarTablaAsistencia();
}

function poblarTablaAsistencia(){
	$.ajax({
		type:"post",
		url:"/paginaprofesor/",
		data:"idcurso="+$("#idcurso").val(),
		success:function(res){
			$("#tablaenblanco").remove();
			$("#tablaasistencia tbody").remove();
			for(var x=0; x<res.length;x++){
				$("#tablaasistencia").append("<tbody><tr style='background:#fff' onclick='tablanotas("+x+")'><td>"+res[x].nombrealumno+" "+res[x].alumnapellidopat+"</td>" +
						"<td>"+ +"</td>" +
						"<td>"+ +"</td></tr></tbody>").text();
			}
			b=res;
			}
	});
}
