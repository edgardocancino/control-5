function Tabla_AnotacionesController(option){
	$("#msg").hide();
	$("#msg").removeClass("alert-success").addClass("alert-danger");
	var token = $("meta[name='_csrf']").attr("content");
	
	switch(option){
	case "list":
		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/anotacionespage/list",
			success : function(res) {
				$('#tabla_anotacionestable').bootstrapTable('load', res);
				$('#tabla_anotacionestable tbody').on('click', 'tr', function () {
					$("#idanotaciones").val($(this).find("td:eq(0)").text());
					$("#positiva").val($(this).find("td:eq(1)").text());
					$("#negativa").val($(this).find("td:eq(2)").text());
					$("#atrasos").val($(this).find("td:eq(3)").text());
					$("#rutalumno").val($(this).find("td:eq(4)").text());
					});
				$("#mymodal").modal({show:true});
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("Error en busqueda de anotaciones.")
			}
		});       			
		break;
	case "get":
		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/anotacionespage/get",
			data : "idanotaciones="+$("#idanotaciones").val(),
			success : function(res) {
				if (res == null || res == "") {
					$("#msg").show();
					$("#msg").html("No se encontraron registros.");
				} else {	
					$("#idanotaciones").val(res.idanotaciones);
					$("#positiva").val(res.positiva);
					$("#negativa").val(res.negativa);
					$("#atrasos").val(res.atrasos);
					$("#rutalumno").val(res.rutalumno);
				}
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("Error en busqueda.");
			}
		});       			
		break;
	case "insert":
		$("#idanotaciones").val(0),
		$("#positiva").val(""),
		$("#negativa").val(""),
		$("#atrasos").val(""),
		$("#rutalumno").val("")
		break;
	case "update":
		var json = 
			{
				'idanotaciones': $("#idanotaciones").val(),
				'positiva': $("#positiva").val(),
				'negativa': $("#negativa").val(),
				'atrasos': $("atrasos").val(),
				'rutalumno': $("#rutalumno").val(),
			};

		var postData = JSON.stringify(json);

		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/anotacionespage/update",
			data : postData,
			contentType : "application/json; charset=utf-8",
			dataType : "json",
			success : function(res) {
				if (res == 1) {
					$("#msg").removeClass("alert-danger").addClass("alert-success");
					$("#msg").show();
					$("#msg").html("Registro modificado correctamente.");
				} else {
					$("#msg").show();
					$("#msg").html("No se pudo modificar el registro.");
				}
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("No se pudo modificar el registro.");
			}
		});       	
    break;
	case "delete":
		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/anotacionespage/delete",
			data : "idanotaciones="+$("#idanotaciones").val(),
			success : function(res) {
				if (res == 1) {
					$("#msg").removeClass("alert-danger").addClass("alert-success");
					$("#msg").show();
					$("#msg").html("Registro eliminado correctamente.");
				} else {
					$("#msg").show();
					$("#msg").html("No se pudo eliminar el registro.");
				}
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("No se pudo eliminar el registro.");
			}
		});
		break;
	default:
		$("#msg").show();
		$("#msg").html("Opción incorrecta.");
	}
}
