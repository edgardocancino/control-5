function MensualidadesController(option){
	$("#msg").hide();
	$("#msg").removeClass("alert-success").addClass("alert-danger");
	var token = $("meta[name='_csrf']").attr("content");
	
	switch(option){
	case "list":
		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/mensualidades/list",
			success : function(res) {
				$('#mensualidadestable').bootstrapTable('load', res);
				$('#mensualidadestable tbody').on('click', 'tr', function () {
					$("#idmensualidad").val($(this).find("td:eq(0)").text());
					$("#idalumno").val($(this).find("td:eq(1)").text());
					$("#enero").val($(this).find("td:eq(2)").text());
					$("#febrero").val($(this).find("td:eq(3)").text());
					$("#marzo").val($(this).find("td:eq(4)").text());
					$("#abril").val($(this).find("td:eq(5)").text());
					$("#mayo").val($(this).find("td:eq(6)").text());
					$("#junio").val($(this).find("td:eq(7)").text());
					$("#julio").val($(this).find("td:eq(8)").text());
					$("#agosto").val($(this).find("td:eq(9)").text());
					$("#septiembre").val($(this).find("td:eq(10)").text());
					$("#octubre").val($(this).find("td:eq(11)").text());
					$("#noviembre").val($(this).find("td:eq(12)").text());
					$("#diciembre").val($(this).find("td:eq(13)").text());
					$("#año").val($(this).find("td:eq(14)").text());
					$("#mymodal .close").click();
				});
				$("#mymodal").modal({show:true});
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("Error en busqueda de mensualidades.")
			}
		});       			
		break;
	case "get":
		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/mensualidades/get",
			data : "idmensualidad="+$("#idmensualidad").val(),
			success : function(res) {
				if (res == null || res == "") {
					$("#msg").show();
					$("#msg").html("No se encontraron registros.");
				} else {	
					$("#idmensualidad").val(res.idmensualidad);
					$("#idalumno").val(res.idalumno);
					$("#enero").val(res.enero);
					$("#febrero").val(res.febrero);
					$("#marzo").val(res.marzo);
					$("#abril").val(res.abril);
					$("#mayo").val(res.mayo);
					$("#junio").val(res.junio);
					$("#julio").val(res.julio);
					$("#agosto").val(res.agosto);
					$("#septiembre").val(res.septiembre);
					$("#octubre").val(res.octubre);
					$("#noviembre").val(res.noviembre);
					$("#diciembre").val(res.diciembre);
					$("#año").val(res.año);
				}
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("Error en busqueda.");
			}
		});       			
		break;
	case "insert":
		$("#idmensualidad").val(0),
		$("#idalumno").val(0),
		$("#enero").val(""),
		$("#febrero").val("");
		$("#marzo").val("");
		$("#abril").val("");
		$("#mayo").val("");
		$("#junio").val("");
		$("#julio").val("");
		$("#agosto").val("");
		$("#septiembre").val("");
		$("#octubre").val("");
		$("#noviembre").val("");
		$("#diciembre").val("");
		$("#año").val(0)
	    break;
	case "update":
		var json = 
			{
				'idmensualidad': $("#idmensualidad").val(),
				'idalumno': $("#idalumno").val(),
				'enero': $("#enero").val(),
				'febrero': $("#febrero").val(),
				'marzo': $("#marzo").val(),
				'abril': $("#abril").val(),
				'mayo': $("#mayo").val(),
				'junio':  $("#junio").val(),
				'julio':  $("#julio").val(),
				'agosto':  $("#agosto").val(),
				'septiembre':  $("#septiembre").val(),
				'octubre':  $("#octubre").val(),
				'noviembre':  $("#noviembre").val(),
				'diciembre':  $("#diciembre").val(),
				'año':  $("#año").val()
			};

		var postData = JSON.stringify(json);

		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/mensualidades/update",
			data : postData,
			contentType : "application/json; charset=utf-8",
			dataType : "json",
			success : function(res) {
				if (res == 1) {
					$("#msg").removeClass("alert-danger").addClass("alert-success");
					$("#msg").show();
					$("#msg").html("Registro modificado correctamente.");
				} else {
					$("#msg").show();
					$("#msg").html("No se pudo modificar el registro.");
				}
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("No se pudo modificar el registro.");
			}
		});       	
    break;
	case "delete":
		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/mensualidades/delete",
			data : "idmensualidad="+$("#idmensualidad").val(),
			success : function(res) {
				if (res == 1) {
					$("#msg").removeClass("alert-danger").addClass("alert-success");
					$("#msg").show();
					$("#msg").html("Registro eliminado correctamente.");
				} else {
					$("#msg").show();
					$("#msg").html("No se pudo eliminar el registro.");
				}
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("No se pudo eliminar el registro.");
			}
		});
		break;
	default:
		$("#msg").show();
		$("#msg").html("Opción incorrecta.");
	}
}
