package com.example.demo.model.dao;

import com.example.demo.model.dto.AsistenciaDTO;

public interface AsistenciaDAO {
	
	public int insertasistencia(AsistenciaDTO asistencia);
	
	public AsistenciaDTO getasistencia(AsistenciaDTO asistencia);

}
