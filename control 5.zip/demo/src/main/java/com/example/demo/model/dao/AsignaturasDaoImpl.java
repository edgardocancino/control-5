package com.example.demo.model.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.dto.AsignaturasDTO;
import com.example.demo.model.dto.CuentasDTO;
@Repository
@Transactional
public class AsignaturasDaoImpl implements AsignaturasDAO {

	public String getasignatura= "SELECT * FROM TABLA_ASIGNATURA WHERE ID_ASIGNATURA=?"; 
	

	@Autowired
	JdbcTemplate jdbctemplate;
	
	@Override
	public AsignaturasDTO getasignatura(Integer idasignatura) {
		Object[] args= {idasignatura};
		AsignaturasDTO asignaturas;
		try {
			asignaturas = jdbctemplate.queryForObject(getasignatura,args,BeanPropertyRowMapper.newInstance(AsignaturasDTO.class));
		}
		catch(EmptyResultDataAccessException e) {
	    	asignaturas=null;
	    	e.printStackTrace();
	    } catch (Exception e) {
	    	asignaturas=null;
	    	e.printStackTrace();
	    }
		return asignaturas;
	}
}
