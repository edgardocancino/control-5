package com.example.demo.controller;

import java.io.IOException;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.dto.NotasDTO;
import com.example.demo.service.NotasService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Controller
@RequestMapping(value="/paginanotas")
public class NotasController {
	@Autowired
	NotasService notasservice;
	
	@RequestMapping(value="/updatenotas")
	public @ResponseBody int ajaxupdatenotas(HttpServletRequest req, HttpServletResponse res) {
		int rows=0;
		try {
			String RequestData = req.getReader().lines().collect(Collectors.joining());
			Gson gson = new GsonBuilder().setDateFormat("dd-mm-yy").create();
			NotasDTO notas = gson.fromJson(RequestData, NotasDTO.class);
			rows=notasservice.updatenotas(notas);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	return rows;	
	}
}
