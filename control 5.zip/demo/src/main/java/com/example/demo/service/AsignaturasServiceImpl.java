package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.dao.AsignaturasDAO;
import com.example.demo.model.dto.AsignaturasDTO;
@Service
public class AsignaturasServiceImpl implements AsignaturasService {
	@Autowired
	AsignaturasDAO asignaturasdao;
	@Override
	public AsignaturasDTO getasignatura(Integer idasignatura) {
		return asignaturasdao.getasignatura(idasignatura);
	}

}
