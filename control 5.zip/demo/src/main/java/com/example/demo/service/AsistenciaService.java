package com.example.demo.service;

import com.example.demo.model.dto.AsistenciaDTO;

public interface AsistenciaService {
	
	public int insertasistencia(AsistenciaDTO asistencia);
	
	public AsistenciaDTO getasistencia(AsistenciaDTO asistencia);
	

}
