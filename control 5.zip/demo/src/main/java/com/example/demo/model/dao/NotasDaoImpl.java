package com.example.demo.model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.dto.NotasDTO;
@Repository
@Transactional
public class NotasDaoImpl implements NotasDAO {
	private String getnotas="SELECT * FROM TABLA_NOTAS WHERE RUTALUMNO=?";
	private String updatenotas="UPDATE TABLA_NOTAS SET NOTA1=?, NOTA2=?, NOTA3=?, PROMEDIO=? WHERE RUTALUMNO=? AND IDASIGNATURA=?";
	
	@Autowired
	JdbcTemplate jdbctemplate;
	
	@Override
	public List<NotasDTO> getnotas(Integer rutalumno) {
		Object[] args= {rutalumno};
		return jdbctemplate.query(getnotas,args,new RowMapper<NotasDTO>() {
			@Override
			public NotasDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				NotasDTO notas=new NotasDTO();
				notas.setIdnotas(rs.getInt("IDNOTAS"));
				notas.setNota1(rs.getFloat("NOTA1"));
				notas.setNota2(rs.getFloat("NOTA2"));
				notas.setNota3(rs.getFloat("NOTA3"));
				notas.setRutalumno(rs.getInt("RUTALUMNO"));
				notas.setIdasignatura(rs.getInt("IDASIGNATURA"));
				notas.setPromedio(rs.getFloat("PROMEDIO"));
				return notas;
			}
			});
	}

	@Override
	public int updatenotas(NotasDTO notasdto) {
		int rows=0;
		Object[] args={
			notasdto.getNota1(),
			notasdto.getNota2(),
			notasdto.getNota3(),
			notasdto.getPromedio(),
			notasdto.getRutalumno(),
			notasdto.getIdasignatura()};
		try {
			rows=jdbctemplate.update(updatenotas,args);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return rows;
	}
}
