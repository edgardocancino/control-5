package com.example.demo.model.dto;

public class CursosDTO {
	private Integer idcurso;
	private String curnivel;
	private String curletra;
	private Integer año;
	private Integer id_asignatura;
	private Integer rutprofesor;
	private Integer idcurso_asig;
	
	public CursosDTO() {
	}

	public Integer getIdcurso() {
		return idcurso;
	}

	public void setIdcurso(Integer idcurso) {
		this.idcurso = idcurso;
	}

	public String getCurnivel() {
		return curnivel;
	}

	public void setCurnivel(String curnivel) {
		this.curnivel = curnivel;
	}

	public String getCurletra() {
		return curletra;
	}

	public void setCurletra(String curletra) {
		this.curletra = curletra;
	}

	public Integer getAño() {
		return año;
	}

	public void setAño(Integer año) {
		this.año = año;
	}

	public Integer getId_asignatura() {
		return id_asignatura;
	}

	public void setId_asignatura(Integer id_asignatura) {
		this.id_asignatura = id_asignatura;
	}

	public Integer getRutprofesor() {
		return rutprofesor;
	}

	public void setRutprofesor(Integer rutprofesor) {
		this.rutprofesor = rutprofesor;
	}

	public Integer getIdcurso_asig() {
		return idcurso_asig;
	}

	public void setIdcurso_asig(Integer idcurso_asig) {
		this.idcurso_asig = idcurso_asig;
	}
	
	
	
}
