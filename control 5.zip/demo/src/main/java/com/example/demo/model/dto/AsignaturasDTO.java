package com.example.demo.model.dto;

public class AsignaturasDTO {
	private Integer id_asignatura;
	private String asignombre;
	
	public AsignaturasDTO() {
	}
	
	public Integer getId_asignatura() {
		return id_asignatura;
	}

	public void setId_asignatura(Integer id_asignatura) {
		this.id_asignatura = id_asignatura;
	}

	public String getAsignombre() {
		return asignombre;
	}
	public void setAsignombre(String asignombre) {
		this.asignombre = asignombre;
	}
	
	
}
