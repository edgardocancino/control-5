package com.example.demo.model.dto;

public class ApoderadosDTO {
	private String rutapoderado;
	private String sigitoverificadorapoderado;
	private String nombre_apoderado;
	private String apellidopatapoderado;
	private String apellidomatapoderado;
	private String correoapoderado;
	
	public ApoderadosDTO() {	
	}

	public String getRutapoderado() {
		return rutapoderado;
	}

	public void setRutapoderado(String rutapoderado) {
		this.rutapoderado = rutapoderado;
	}

	public String getSigitoverificadorapoderado() {
		return sigitoverificadorapoderado;
	}

	public void setSigitoverificadorapoderado(String sigitoverificadorapoderado) {
		this.sigitoverificadorapoderado = sigitoverificadorapoderado;
	}

	public String getNombre_apoderado() {
		return nombre_apoderado;
	}

	public void setNombre_apoderado(String nombre_apoderado) {
		this.nombre_apoderado = nombre_apoderado;
	}

	public String getApellidopatapoderado() {
		return apellidopatapoderado;
	}

	public void setApellidopatapoderado(String apellidopatapoderado) {
		this.apellidopatapoderado = apellidopatapoderado;
	}

	public String getApellidomatapoderado() {
		return apellidomatapoderado;
	}

	public void setApellidomatapoderado(String apellidomatapoderado) {
		this.apellidomatapoderado = apellidomatapoderado;
	}

	public String getCorreoapoderado() {
		return correoapoderado;
	}

	public void setCorreoapoderado(String correoapoderado) {
		this.correoapoderado = correoapoderado;
	}
	
	
	
	

}
