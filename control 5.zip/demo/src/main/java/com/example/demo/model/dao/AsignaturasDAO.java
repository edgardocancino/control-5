package com.example.demo.model.dao;

import com.example.demo.model.dto.AsignaturasDTO;

public interface AsignaturasDAO {
	
	public AsignaturasDTO getasignatura(Integer idasignatura);

}
