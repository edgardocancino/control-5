package com.example.demo.service;

import java.util.List;

import com.example.demo.model.dto.AlumnosDTO;
import com.example.demo.model.dto.ProfesoresDTO;


public interface ProfesoresService {
	
	public List<ProfesoresDTO> lista();
	
	public List<ProfesoresDTO>listacompleta();
	
	public List<AlumnosDTO> listaalumnoscurso(Integer idcurso);

}
