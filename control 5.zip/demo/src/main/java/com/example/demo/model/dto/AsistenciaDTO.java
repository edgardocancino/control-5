package com.example.demo.model.dto;

public class AsistenciaDTO {
	
	private Integer idasistencia;
	private String meses;
	private Integer dia;
	private Integer año;
	private boolean asistencia;
	private Integer rutalumno;
	
	public AsistenciaDTO() {
	}
	public Integer getIdasistencia() {
		return idasistencia;
	}
	public void setIdasistencia(Integer idasistencia) {
		this.idasistencia = idasistencia;
	}
	public String getMeses() {
		return meses;
	}
	public void setMeses(String meses) {
		this.meses = meses;
	}
	public Integer getDia() {
		return dia;
	}
	public void setDia(Integer dia) {
		this.dia = dia;
	}
	public Integer getAño() {
		return año;
	}
	public void setAño(Integer año) {
		this.año = año;
	}
	public boolean isAsistencia() {
		return asistencia;
	}
	public void setAsistencia(boolean asistencia) {
		this.asistencia = asistencia;
	}
	public Integer getRutalumno() {
		return rutalumno;
	}
	public void setRutalumno(Integer rutalumno) {
		this.rutalumno = rutalumno;
	}
	
	

}
