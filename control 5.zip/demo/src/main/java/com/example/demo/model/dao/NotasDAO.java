package com.example.demo.model.dao;

import java.util.List;

import com.example.demo.model.dto.NotasDTO;

public interface NotasDAO {
	
	public List<NotasDTO> getnotas(Integer rutalumno);
	
	public int updatenotas(NotasDTO notasdto);

}
