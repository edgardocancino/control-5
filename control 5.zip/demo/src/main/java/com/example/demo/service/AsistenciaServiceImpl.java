package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.dao.AsistenciaDAO;
import com.example.demo.model.dto.AsistenciaDTO;
@Service
public class AsistenciaServiceImpl implements AsistenciaService {
	@Autowired
	AsistenciaDAO asistenciadao;
	
	@Override
	public int insertasistencia(AsistenciaDTO asistencia) {
		return asistenciadao.insertasistencia(asistencia);
	}

	@Override
	public AsistenciaDTO getasistencia(AsistenciaDTO asistencia) {
		return asistenciadao.getasistencia(asistencia);
	}

}
