package com.example.demo.service;

import java.util.List;

import com.example.demo.model.dto.NotasDTO;

public interface NotasService {
	
	public List<NotasDTO> getnotas(Integer rutalumno);
	
	public int updatenotas(NotasDTO notasdto);

}
