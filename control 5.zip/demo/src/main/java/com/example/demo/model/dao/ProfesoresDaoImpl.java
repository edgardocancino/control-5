package com.example.demo.model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.dto.AlumnosDTO;
import com.example.demo.model.dto.ProfesoresDTO;

@Repository
@Transactional
public class ProfesoresDaoImpl implements ProfesoresDAO {
	public String listar="SELECT * FROM TABLA_PROFESOR";
	public String get_cursos="SELECT c.curnivel, c.curletra, c.idcurso, c.id_asignatura, b.rutprofesor FROM TABLA_PROFESOR B, TABLA_CURSO C WHERE b.rutprofesor=c.rutprofesor AND b.rutprofesor=17772781";
	public String get_alumnos="SELECT NOMBREALUMNO, ALUMNAPELLIDOPAT,ALUMNAPELLIDOMAT, RUTALUMNO, ID_CURSO FROM TABLA_ALUMNO WHERE ID_CURSO=?";
	@Autowired
	JdbcTemplate jdbctemplate;

	@Override
	public int insert(ProfesoresDTO profesoresdto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ProfesoresDTO get(Integer rutprofesor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int update(ProfesoresDTO profesoresdto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(int id_cuenta) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<ProfesoresDTO> lista() {
		List<ProfesoresDTO> profesoresdto=jdbctemplate.query(listar, BeanPropertyRowMapper.newInstance(ProfesoresDTO.class));
		return profesoresdto;
	}

	@Override
	public List<ProfesoresDTO> listacursos() {
		
		List<ProfesoresDTO> profesoresdto=jdbctemplate.query(get_cursos,BeanPropertyRowMapper.newInstance(ProfesoresDTO.class));
		return profesoresdto;
	}
	
	public List<AlumnosDTO> listaalumnoscurso(Integer idcurso){
		Object[] args= {idcurso};
		return jdbctemplate.query(get_alumnos,args,new RowMapper<AlumnosDTO>() {
			@Override
			public AlumnosDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				AlumnosDTO alumnos=new AlumnosDTO();
				alumnos.setNombrealumno(rs.getString("NOMBREALUMNO"));
				alumnos.setAlumnapellidopat(rs.getString("ALUMNAPELLIDOPAT"));
				alumnos.setAlumnapellidomat(rs.getString("ALUMNAPELLIDOMAT"));
				alumnos.setRutalumno(rs.getInt("RUTALUMNO"));
				alumnos.setId_curso(rs.getInt("ID_CURSO"));
				return alumnos;
			}
			
		});
		
	}
}
