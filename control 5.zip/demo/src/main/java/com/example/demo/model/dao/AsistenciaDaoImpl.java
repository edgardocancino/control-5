package com.example.demo.model.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.dto.AsistenciaDTO;
@Repository
@Transactional
public class AsistenciaDaoImpl implements AsistenciaDAO {
	
public String insertasist="INSERT INTO TABLA_ASISTENCIA VALUES (?,?,?,?,?)";
public String getasistencia="SELECT * FROM TABLA_ASISTENCIA WHERE RUTALUMNO=?,DIAS=?,MESES=?,AÑO=?";
	
	@Autowired
	JdbcTemplate jdbctemplate;
	
	@Override
	public int insertasistencia(AsistenciaDTO a) {
		int rows=0;
		Object[] args= {
				a.getMeses(),
				a.getDia(),
				a.getAño(),
				a.isAsistencia(),
				a.getRutalumno()
		};
		try {
			rows=jdbctemplate.update(insertasist,args); 
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
		return rows;
	}

	@Override
	public AsistenciaDTO getasistencia(AsistenciaDTO asistencia) {
		AsistenciaDTO asistenciadto=null;
		Object[] args= {
			asistencia.getRutalumno(),
			asistencia.getDia(),
			asistencia.getMeses(),
			asistencia.getAño()
		};
		try {
			asistenciadto=jdbctemplate.queryForObject(getasistencia,args, BeanPropertyRowMapper.newInstance(AsistenciaDTO.class));
		}
		catch(EmptyResultDataAccessException e) {
	    	asistenciadto=null;
	    	e.printStackTrace();
	    } catch (Exception e) {
	    	asistenciadto=null;
	    	e.printStackTrace();
	    }
		
		return asistenciadto;
	}

}
