package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.dto.AlumnosDTO;
import com.example.demo.model.dto.AsignaturasDTO;
import com.example.demo.model.dto.NotasDTO;
import com.example.demo.model.dto.ProfesoresDTO;
import com.example.demo.service.AlumnosService;
import com.example.demo.service.AsignaturasService;
import com.example.demo.service.NotasService;
import com.example.demo.service.ProfesoresService;


@Controller
@RequestMapping(value="/paginaprofesor")
public class ProfesorController {
	
	@Autowired
	AlumnosService alumnosservice;
	@Autowired
	ProfesoresService profesoresservice;
	@Autowired
	AsignaturasService asignaturaservice;
	@Autowired
	NotasService notasservice;
	@RequestMapping(value="/list")
	public @ResponseBody List<AlumnosDTO> ajaxList(HttpServletRequest req, HttpServletResponse res){
		List<AlumnosDTO> list = alumnosservice.listar();
		return list;
	}
	@RequestMapping(value="/listacurso")
	public @ResponseBody List<ProfesoresDTO> ajaxListcursos(HttpServletRequest req, HttpServletResponse res){
		List<ProfesoresDTO> a=profesoresservice.lista();
		return a;
		
	}
	@RequestMapping(value="/listaalumnocurso")
	public @ResponseBody List<AlumnosDTO> ajaxlistaalumnoscurso(HttpServletRequest req, HttpServletResponse res){
		List<AlumnosDTO> lista=profesoresservice.listaalumnoscurso(Integer.parseInt(req.getParameter("idcurso")));
		return lista;
	}
	@RequestMapping(value="/obtenerasignatura")
	public @ResponseBody AsignaturasDTO ajaxgetasignatura(HttpServletRequest req, HttpServletResponse res) {
		AsignaturasDTO asignatura=asignaturaservice.getasignatura(Integer.parseInt(req.getParameter("id_asignatura")));
		return asignatura;
	}
	@RequestMapping(value="/obtenernotas")
	public @ResponseBody List<NotasDTO> ajaxgetnotas(HttpServletRequest req, HttpServletResponse res) {
		List<NotasDTO> notasdto =notasservice.getnotas(Integer.parseInt(req.getParameter("rutalumno")));
		return notasdto;	
	}
	
	
}
