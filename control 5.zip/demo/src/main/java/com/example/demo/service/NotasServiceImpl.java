package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.dao.NotasDAO;
import com.example.demo.model.dto.NotasDTO;
@Service
public class NotasServiceImpl implements NotasService {

	@Autowired
	NotasDAO notasdao;
	
	@Override
	public List<NotasDTO> getnotas(Integer rutalumno) {
		return notasdao.getnotas(rutalumno);
	}

	@Override
	public int updatenotas(NotasDTO notasdto) {
		return notasdao.updatenotas(notasdto);
	}

}
