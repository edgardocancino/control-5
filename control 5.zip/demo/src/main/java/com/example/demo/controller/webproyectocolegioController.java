package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class webproyectocolegioController  {
	@RequestMapping("/")	
	public String getHome() {
		return "index";
	}
       
		@RequestMapping("/anotacionespage")
		public String getTabla_Anotaciones() {
			return "anotacionespage";
    }
		@RequestMapping("/alumnos")
		public String getAlumnos() {
			return "alumnos";
		}
		
		@RequestMapping("/loginapoderado")
		public String getloginapoderado() {
			return "loginapoderado";
    }
		@RequestMapping("/loginprofesor")
		public String getloginprofesor() {
			return "loginprofesor";
    }
		@RequestMapping("/Notas")
		public String getNotas() {
			return "notas";
	}
		@RequestMapping("/mensualidades")
		public String getmensualidades() {
			return "mensualidades";
	}
		@RequestMapping("/paginatablas")
		public String getpaginatablas() {
			return "paginatablas";
	}
		@RequestMapping("/paginatablasprofe")
		public String getpaginatablasprofe() {
			return "paginatablasprofe";
	}
		@RequestMapping("/paginaprofesor")
		public String getpaginaprofesor() {
			return "paginaprofesor";
	}
		@RequestMapping("/asistencia")
		public String getasistencia() {
			return "asistencia";
	}
		@RequestMapping("/loginadministrador")
		public String getloginadministrador() {
			return "loginadministrador";
	}
		@RequestMapping("/paginatablasadmin")
		public String getpaginatablasadmin() {
			return "paginatablasadmin";
	}
		@RequestMapping("/alumnosAdmin")
		public String getalumnosAdmin() {
			return "alumnosAdmin";
	}
		@RequestMapping("/notasAdmin")
		public String getnotasAdmin() {
			return "notasAdmin";
	}
		@RequestMapping("/asistenciaAdmin")
		public String getasistenciaAdmin() {
			return "asistenciaAdmin";
	}	
		@RequestMapping("/anotacionesAdmin")
		public String getanotacionesAdmin() {
			return "anotacionesAdmin";
	}
		@RequestMapping("/mensualidadesAdmin")
		public String getmensualidadesAdmin() {
			return "mensualidadesAdmin";
	}
		@RequestMapping("/paginaAsistencia")
		public String getpaginaAsistencia() {
			return "paginaAsistencia";
	}	
}	

