package com.example.demo.service;

import com.example.demo.model.dto.AsignaturasDTO;

public interface AsignaturasService {
	
	public AsignaturasDTO getasignatura(Integer idasignatura);

}
